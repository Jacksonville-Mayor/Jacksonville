#pragma once

namespace game {
namespace hook {
void init();
} // hook
} // game
